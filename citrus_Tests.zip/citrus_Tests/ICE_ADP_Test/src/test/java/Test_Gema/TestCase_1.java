package Test_Gema;

import org.testng.annotations.Test;

import com.consol.citrus.annotations.CitrusXmlTest;
import com.consol.citrus.testng.AbstractTestNGCitrusTest;

/**

 */
@Test 

public class TestCase_1 extends AbstractTestNGCitrusTest {


	@CitrusXmlTest(name = "TestCase_1")
    public void testCase1Gema() {}

 
}


