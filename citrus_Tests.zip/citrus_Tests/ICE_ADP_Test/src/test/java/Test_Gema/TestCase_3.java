package Test_Gema;

import org.testng.annotations.Test;

import com.consol.citrus.annotations.CitrusXmlTest;
import com.consol.citrus.testng.AbstractTestNGCitrusTest;

/**

 */
@Test

public class TestCase_3 extends AbstractTestNGCitrusTest {


	@CitrusXmlTest(name = "TestCase_3")
    public void testCase3Gema() {}

 
}


