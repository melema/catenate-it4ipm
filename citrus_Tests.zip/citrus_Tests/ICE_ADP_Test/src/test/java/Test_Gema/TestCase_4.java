package Test_Gema;

import org.testng.annotations.Test;

import com.consol.citrus.annotations.CitrusXmlTest;
import com.consol.citrus.testng.AbstractTestNGCitrusTest;

/**

 */
@Test

public class TestCase_4 extends AbstractTestNGCitrusTest {


	@CitrusXmlTest(name = "TestCase_4")
    public void testCase4Gema() {}

 
}


