package Test_Gema;

import org.testng.annotations.Test;

import com.consol.citrus.annotations.CitrusXmlTest;
import com.consol.citrus.testng.AbstractTestNGCitrusTest;

/**

 */
@Test

public class TestCase_10 extends AbstractTestNGCitrusTest {


	@CitrusXmlTest(name = "TestCase_10")
    public void testCase10Gema() {}

}