package Test_Gema;

import org.testng.annotations.Test;

import com.consol.citrus.annotations.CitrusXmlTest;
import com.consol.citrus.testng.AbstractTestNGCitrusTest;

/**

 */
@Test

public class TestCase_9 extends AbstractTestNGCitrusTest {


	@CitrusXmlTest(name = "TestCase_9")
    public void testCase9Gema() {}

}