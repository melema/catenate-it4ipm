package Test_Gema;

import org.testng.annotations.Test;

import com.consol.citrus.annotations.CitrusXmlTest;
import com.consol.citrus.testng.AbstractTestNGCitrusTest;

/**

 */
@Test

public class TestCase_7 extends AbstractTestNGCitrusTest {


	@CitrusXmlTest(name = "TestCase_7")
    public void testCase7Gema() {}

}